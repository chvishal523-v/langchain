# LangChain — Introduction (Beginner-Friendly)

LangChain is an open-source framework for building applications powered by **LLMs (Large Language Models)** like Gemini, GPT, Claude, etc.  
It gives you **reusable building blocks** (prompts, models, tools, retrievers, memory/state, structured output) so you can ship real apps instead of only chatting in a UI.

---

## What you can build with LangChain

- **Chatbots & copilots** (FAQ bots, support agents, internal assistants)
- **RAG apps** (ask questions over PDFs, docs, Notion, DBs)
- **Agents** (LLM that can use tools: web search, APIs, DB queries, automation workflows)
- **Workflow + tool pipelines** (summarization, extraction, classification, routing)
- **Production services** (wrap your LLM logic as an API, add tracing, evals, and monitoring)

---

## The LangChain ecosystem (important)

LangChain isn’t just one library—it's an ecosystem:

- **LangChain**: the core “lego blocks” for LLM apps (models, prompts, runnables, tools, retrievers, etc.)
- **LangGraph**: a lower-level framework to build **durable, stateful agents/workflows** (streaming, human-in-the-loop, persistence, retries).  
  LangChain agents are built on top of LangGraph for more advanced needs.
- **LangSmith**: tracing, evaluation, and monitoring for your LLM/agent runs
- **LangServe**: helpers for serving LangChain “runnables” as APIs

> Tip: Start with LangChain. Move to LangGraph when you need complex agent workflows, state, and reliability.

---

## Core concepts (the “lego blocks”)

### 1) Models
A “model” is your LLM provider wrapper (Gemini / OpenAI / Anthropic / etc.).  
You can swap providers without rewriting your whole app.

### 2) Prompts
Prompts are templates that help you produce consistent outputs.

### 3) Output Parsers + Structured Output
Instead of parsing messy text, you can ask the model to return **JSON / Pydantic**.

### 4) Runnables (LCEL)
LangChain encourages composing steps like a pipeline:

`Prompt → Model → Parser → (your code)`

### 5) Retrieval (RAG)
“Retrieval-Augmented Generation” lets the model answer using your private data:
- Load documents
- Split into chunks
- Embed chunks into vectors
- Store in a vector database
- Retrieve relevant chunks at question time
- Generate an answer grounded in those chunks

### 6) Tools + Agents
Agents are LLMs that **decide** which tools to call:
- call APIs
- do calculations
- read files
- search
- automate actions

---

## Quickstart (Python)

### Prerequisites
- Python 3.10+ recommended
- A Google AI (Gemini) API key (from Google AI Studio)

### Recommended install
For this beginner intro, we’ll use Gemini:

```bash
pip install -U langchain-google-genai python-dotenv
```

> `langchain-google-genai` is the LangChain integration package for Google Gemini.

---

## Setup environment variables

Create a `.env` file in your project root:

```env
GOOGLE_API_KEY=your_gemini_api_key_here
```

We include a `.env.example` file in this zip.

---

## Example 1 — “Hello, LangChain” with Gemini

File: `examples/00_hello_world_gemini.py`

What it shows:
- load `.env`
- create a Gemini chat model
- call `.invoke()` to get a response

Run:

```bash
python examples/00_hello_world_gemini.py
```

---

## Example 2 — Prompt → Model → Text (a simple pipeline)

File: `examples/01_prompt_pipeline.py`

What it shows:
- PromptTemplate
- Compose a pipeline
- Parse output into plain text

Run:

```bash
python examples/01_prompt_pipeline.py
```

---

## Common beginner mistakes

### 1) “My API key isn’t picked up”
- Ensure you created `.env`
- Ensure it’s named exactly `.env` (not `.env.txt`)
- Ensure you installed `python-dotenv`

### 2) “I get auth errors”
- Your key might be wrong/expired
- Confirm the key is enabled and active in Google AI Studio

### 3) “My outputs are inconsistent”
- Use stronger prompts (explicit format)
- Use structured output / parsers where possible
- Set temperature lower (e.g., 0–0.3) for deterministic behavior

---

## Next steps (learning path)

1) Build 3 tiny apps:
   - Summarizer
   - JSON extractor (structured output)
   - RAG over a small PDF/text file

2) Add tools:
   - One API tool (call a public endpoint)
   - One “calculator” tool

3) Graduate to LangGraph when you need:
   - multi-step agent workflows
   - retries + persistence
   - human approval steps
   - long-running tasks

---

## Helpful official docs (search these)
- “ChatGoogleGenerativeAI LangChain”
- “LangChain structured output”
- “LangGraph overview”
- “LangSmith tracing”
