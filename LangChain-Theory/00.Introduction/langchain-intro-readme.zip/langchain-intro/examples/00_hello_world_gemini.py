"""
Hello world: LangChain + Gemini (Google Generative AI)

Setup:
1) pip install -U langchain-google-genai python-dotenv
2) create a .env with GOOGLE_API_KEY=...
3) run: python examples/00_hello_world_gemini.py
"""

import os
from dotenv import load_dotenv
from langchain_google_genai import ChatGoogleGenerativeAI

load_dotenv()

# Gemini Developer API key (preferred env var: GOOGLE_API_KEY)
# Docs: https://docs.langchain.com/oss/python/integrations/chat/google_generative_ai
model = ChatGoogleGenerativeAI(
    model="gemini-2.5-flash",
    temperature=0.2,
    max_retries=2,
)

messages = [
    ("system", "You are a concise assistant."),
    ("human", "Explain LangChain in one sentence."),
]

resp = model.invoke(messages)
print(resp.content)
