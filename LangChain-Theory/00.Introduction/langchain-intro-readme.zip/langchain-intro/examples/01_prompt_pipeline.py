"""
Prompt → Model → Text pipeline (LCEL-style composition)

Run:
python examples/01_prompt_pipeline.py
"""

from dotenv import load_dotenv
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser

load_dotenv()

model = ChatGoogleGenerativeAI(model="gemini-2.5-flash", temperature=0.2)

prompt = ChatPromptTemplate.from_messages([
    ("system", "You are a helpful assistant. Keep answers under 60 words."),
    ("human", "Write a {tone} intro about {topic} for a beginner."),
])

chain = prompt | model | StrOutputParser()

out = chain.invoke({"tone": "simple", "topic": "LangChain"})
print(out)
