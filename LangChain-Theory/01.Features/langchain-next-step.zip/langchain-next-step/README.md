# LangChain — Next Step After Introduction (Features + Building Blocks)

This README is the **next step** after “What is LangChain?”  
Here you’ll learn **what features LangChain provides**, how the pieces fit together, and what to build next.

---

## 1) What LangChain gives you (high-level)

LangChain is an open-source framework for building applications powered by **LLMs (Large Language Models)** with:
- a **pre-built agent architecture**
- lots of **integrations** (models, tools, data sources, vector stores)
- reusable building blocks that you can compose into pipelines

---

## 2) Feature map (the “LangChain toolbox”)

Below are the major features/capabilities you’ll use in real projects.

### A) Models (Chat Models + Embeddings)
**Chat models**
- One interface for many providers (Gemini, OpenAI, Anthropic, etc.)
- Common operations:
  - `invoke()` for a single call
  - `stream()` for streaming tokens (if supported)
  - `batch()` for batching multiple inputs (client-side parallelization)

**Embedding models**
- Convert text into vectors for semantic search / similarity search

---

### B) Messages (Chat input/output format)
- System / human / AI / tool messages
- Carry content + metadata (useful for multi-turn conversations)

---

### C) Prompts (Prompt Templates)
- Reusable templates with variables
- Few-shot examples
- Strong formatting instructions for consistent output

---

### D) Runnables + LCEL (Composable pipelines)
LangChain encourages composing steps into pipelines (chains), like:

`Prompt → Model → Parser → (your code) → Output`

This makes your app:
- modular (swap parts easily)
- testable
- easier to debug

---

### E) Output Parsers + Structured Output (Reliable JSON / Pydantic)
Instead of parsing messy text, you can request predictable output:
- JSON objects
- Pydantic models / dataclasses

See: `examples/02_structured_output_pydantic.py`

---

### F) Tools (Functions the model can call)
Tools let the model call real actions:
- calculations
- API calls
- database queries
- file processing
- automation workflows

See: `examples/03_tool_calling_basic.py`

---

### G) Agents (LLM + Tools in a loop)
Agents combine an LLM with tools so the system can:
- reason about a goal
- choose tools
- iterate until it finishes

Tip: Start with tool calling first, then move to full agents.

---

### H) Retrieval / RAG (Ask questions over your data)
Typical RAG pipeline:
1) Load documents (PDF, website, Notion, DB, etc.)
2) Split text into chunks
3) Embed chunks into vectors
4) Store vectors in a vector DB (or local FAISS)
5) Retrieve relevant chunks at question time
6) Generate an answer grounded in the retrieved context

See: `examples/04_simple_rag_faiss.py`

---

### I) Integrations (Huge ecosystem)
LangChain has integrations by component:
- chat models
- tools/toolkits
- document loaders
- text splitters
- embedding models
- vector stores
- retrievers

---

### J) Memory (Conversation + Long-term context)
For chat/agent apps, memory helps:
- keep conversation history
- store user preferences
- resume sessions

(For advanced, stateful memory and persistence, LangGraph is commonly used.)

---

### K) Observability (Tracing, debugging, monitoring)
In production, you’ll want:
- traces of runs
- tool calls
- latency and errors
- evaluation and testing

LangSmith is commonly used for tracing + evals + monitoring.

---

### L) Deployment / Serving
When your chain/agent is stable, you can serve it as an API.
LangServe is a common approach for serving LangChain runnables.

---

## 3) Recommended installs (Gemini-focused)

Create a virtual environment, then install:

```bash
pip install -U python-dotenv langchain-google-genai
```

For the RAG demo (FAISS + loaders + splitters), also install:

```bash
pip install -U langchain-community langchain-text-splitters faiss-cpu
```

---

## 4) Environment setup

Create `.env`:

```env
GOOGLE_API_KEY=your_gemini_api_key_here
```

We included `.env.example` in this zip.

---

## 5) Run the examples

### Example 2 — Structured output (Pydantic)
```bash
python examples/02_structured_output_pydantic.py
```

### Example 3 — Tool calling (basic)
```bash
python examples/03_tool_calling_basic.py
```

### Example 4 — Simple RAG over local text (FAISS)
```bash
python examples/04_simple_rag_faiss.py
```

---

## 6) Next learning path (practical)

1) **Structured output extractor**
   - Input: messy text
   - Output: clean JSON (Pydantic)

2) **Tool calling mini-assistant**
   - Tools: calculator + simple API fetch

3) **RAG over your files**
   - PDFs, markdown, docs
   - Add citations by returning chunk metadata

4) **Tracing + evals**
   - Turn on LangSmith
   - Evaluate prompts and answers

5) **Move to LangGraph** for robust, stateful workflows
   - persistence, streaming, human-in-the-loop, retries

---

## Folder structure

```
langchain-next-step/
├─ README.md
├─ .env.example
├─ data/
│  └─ sample_docs.txt
└─ examples/
   ├─ 02_structured_output_pydantic.py
   ├─ 03_tool_calling_basic.py
   └─ 04_simple_rag_faiss.py
```

---

## Official docs to read next (search these titles)
- “LangChain overview”
- “Agents (LangChain)”
- “Retrieval / RAG (LangChain)”
- “Structured output (LangChain)”
- “ChatGoogleGenerativeAI (LangChain integration)”
- “GoogleGenerativeAIEmbeddings (LangChain integration)”
- “LangSmith tracing and evaluation”
