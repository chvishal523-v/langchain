"""
Simple RAG over local text (FAISS) with LangChain + Gemini

Install:
  pip install -U python-dotenv langchain-google-genai langchain-community langchain-text-splitters faiss-cpu

Run:
  python examples/04_simple_rag_faiss.py
"""

from __future__ import annotations

from pathlib import Path
from dotenv import load_dotenv

from langchain_google_genai import ChatGoogleGenerativeAI, GoogleGenerativeAIEmbeddings
from langchain_community.document_loaders import TextLoader
from langchain_community.vectorstores import FAISS
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnablePassthrough

load_dotenv()

DATA_PATH = Path(__file__).resolve().parent.parent / "data" / "sample_docs.txt"

docs = TextLoader(str(DATA_PATH), encoding="utf-8").load()

splitter = RecursiveCharacterTextSplitter(chunk_size=350, chunk_overlap=50)
chunks = splitter.split_documents(docs)

embeddings = GoogleGenerativeAIEmbeddings(model="models/text-embedding-004")
db = FAISS.from_documents(chunks, embeddings)
retriever = db.as_retriever(search_kwargs={"k": 3})

prompt = ChatPromptTemplate.from_messages([
    ("system", "Answer using ONLY the provided context. If missing, say 'I don't know'."),
    ("human", "Question: {question}\\n\\nContext:\\n{context}"),
])

def format_docs(docs):
    return "\\n\\n".join(d.page_content for d in docs)

llm = ChatGoogleGenerativeAI(model="gemini-2.5-flash", temperature=0.2)

rag_chain = (
    {"context": retriever | format_docs, "question": RunnablePassthrough()}
    | prompt
    | llm
)

question = "What are the main pieces of RAG and why is structured output useful?"
answer = rag_chain.invoke(question)

print(answer.content)
