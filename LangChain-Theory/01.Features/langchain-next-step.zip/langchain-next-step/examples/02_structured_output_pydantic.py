"""
Structured Output (Pydantic) with LangChain + Gemini

Install:
  pip install -U langchain-google-genai python-dotenv pydantic

Run:
  python examples/02_structured_output_pydantic.py
"""

from __future__ import annotations

from dotenv import load_dotenv
from pydantic import BaseModel, Field
from langchain_google_genai import ChatGoogleGenerativeAI

load_dotenv()

class CourseIdea(BaseModel):
    title: str = Field(..., description="A short course title")
    target_audience: str = Field(..., description="Who this is for")
    modules: list[str] = Field(..., description="Module titles")
    duration_days: int = Field(..., description="Estimated duration in days")

llm = ChatGoogleGenerativeAI(
    model="gemini-2.5-flash",
    temperature=0.2,
)

structured_llm = llm.with_structured_output(CourseIdea)

result: CourseIdea = structured_llm.invoke(
    "Create a beginner course idea for LangChain. Keep it practical and job-focused."
)

print(result.model_dump_json(indent=2))
