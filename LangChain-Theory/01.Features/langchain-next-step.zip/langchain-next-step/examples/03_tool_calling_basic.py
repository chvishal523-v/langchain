"""
Tool calling (basic) with LangChain + Gemini

Install:
  pip install -U langchain-google-genai python-dotenv

Run:
  python examples/03_tool_calling_basic.py

Note:
This is a minimal example showing:
- define tools
- bind tools to the model
- model returns tool calls
- you execute the tools and print results
"""

from __future__ import annotations

import math
from dotenv import load_dotenv
from langchain_core.tools import tool
from langchain_google_genai import ChatGoogleGenerativeAI

load_dotenv()

@tool
def circle_area(radius: float) -> float:
    \"\"\"Return area of a circle for a given radius.\"\"\"
    return math.pi * (radius ** 2)

@tool
def add(a: float, b: float) -> float:
    \"\"\"Add two numbers.\"\"\"
    return a + b

llm = ChatGoogleGenerativeAI(model="gemini-2.5-flash", temperature=0.0)
llm_with_tools = llm.bind_tools([circle_area, add])

msg = llm_with_tools.invoke(
    "Radius is 3.5. First compute circle area, then add 10. Return final number."
)

print("MODEL OUTPUT (raw):")
print(msg)

tool_calls = getattr(msg, "tool_calls", None) or []
if not tool_calls:
    print("\\nNo tool calls returned. The model may have answered directly.")
else:
    print("\\nTOOL CALLS:")
    for call in tool_calls:
        print(call)

    print("\\nTOOL RESULTS:")
    for call in tool_calls:
        name = call["name"]
        args = call.get("args", {})
        if name == "circle_area":
            print("circle_area ->", circle_area.invoke(args))
        elif name == "add":
            print("add ->", add.invoke(args))
        else:
            print(name, "-> (unknown tool)")
